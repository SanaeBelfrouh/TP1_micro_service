module com.example.multithreadsblockingio {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.multithreadsblockingio to javafx.fxml;
    exports com.example.multithreadsblockingio;
}