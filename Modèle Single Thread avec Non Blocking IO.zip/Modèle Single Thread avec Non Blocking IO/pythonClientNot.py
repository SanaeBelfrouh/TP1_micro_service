import socket
import sys

# Configuration du serveur
HOST = 'localhost'
PORT = 2222

# Se connecter au serveur
client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client_socket.connect((HOST, PORT))

# Envoyer un message au serveur
message = 'Hello from Python'
client_socket.send(message.encode())

# Recevoir la réponse du serveur
response = client_socket.recv(1024)
print(response.decode())

# Fermer la connexion
client_socket.close()
